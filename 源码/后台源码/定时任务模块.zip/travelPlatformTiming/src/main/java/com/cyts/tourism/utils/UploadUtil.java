package com.cyts.tourism.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * @Author : ZhaoShy
 * @ClassName : UploadUtil
 * @Description : 上传操作工具类
 * @Date : 2021年05月24日 9:33
 * @Vlog : 见贤思齐, 从善如流
 */

@Slf4j
@Configuration
public class UploadUtil {
    @Value("${upload.img.image}")
    private String img_folder;
    @Value("${upload.img.folder}")
    private String file_folder;
    @Value("${upload.img.carousel}")
    private String img_carousel;
    @Value("${upload.server-address}")
    private String serverAddress;

    // 上传图片
    public String imageUpload(MultipartFile[] file, HttpServletRequest request) {
        for (MultipartFile multipartFile : file) {
            long size = multipartFile.getSize();
            try {
                BufferedImage image = ImageIO.read(multipartFile.getInputStream());
                if (Objects.isNull(image)) {
                    return "图片格式不正确";
                }
                if (2L < size / 1048576L) {
                    return "图片不能大于 2M";
                }
                /*if (image.getHeight() > 200 || image.getHeight() > 320) {
                    return "要求分辨率 200 * 200";
                }*/
                String filename = multipartFile.getOriginalFilename();
                String prefixName = filename.substring(0, filename.lastIndexOf("."));
                String suffixName = filename.substring(filename.lastIndexOf("."));
                filename = prefixName + Kit.getOrderID() + suffixName;

                byte[] bytes = multipartFile.getBytes();
                Path path = Paths.get(img_folder + filename);
                //如果没有files文件夹，则创建
                if (!Files.isWritable(path)) {
                    Files.createDirectories(Paths.get(img_folder));
                }
                //文件写入指定路径
                Files.write(path, bytes);
                return request.getScheme() + "://" + serverAddress + ":" + request.getServerPort() + "/images/" + filename;
            } catch (IOException e) {
                e.printStackTrace();
                return "图片上传失败";
            }
        }
        return null;
    }

    //多图片上传
    public List<String> multipleImageUpload(MultipartFile[] file, HttpServletRequest request) {
        List<String> paths = new ArrayList<>();
        for (MultipartFile multipartFile : file) {
            long size = multipartFile.getSize();
            try {
                BufferedImage image = ImageIO.read(multipartFile.getInputStream());
                if (Objects.isNull(image)) {
                    log.info("图片格式不正确");
                    return null;
                }
                if (2L < size / 1048576L) {
                    log.info("图片不能大于 2M");
                    return null;
                }
                /*if (image.getHeight() > 200 || image.getHeight() > 320) {
                    return "要求分辨率 200 * 200";
                }*/
                String filename = multipartFile.getOriginalFilename();
                String prefixName = filename.substring(0, filename.lastIndexOf("."));
                String suffixName = filename.substring(filename.lastIndexOf("."));
                filename = prefixName + Kit.getOrderID() + suffixName;

                byte[] bytes = multipartFile.getBytes();
                Path path = Paths.get(img_carousel + filename);
                //如果没有files文件夹，则创建
                if (!Files.isWritable(path)) {
                    Files.createDirectories(Paths.get(img_carousel));
                }
                //文件写入指定路径
                Files.write(path, bytes);
                String imgPath = request.getScheme() + "://" + serverAddress + ":" + request.getServerPort() + "/carousel/" + filename;
                paths.add(imgPath);
            } catch (IOException e) {
                e.printStackTrace();
                log.info("上传多图片失败" + e);
                return null;
            }
        }
        return paths;
    }

    //多图片上传
    public List<String> multipleFileUpload(MultipartFile[] file, HttpServletRequest request) {
        List<String> paths = new ArrayList<>();
        for (MultipartFile multipartFile : file) {
            long size = multipartFile.getSize();
            try {
                String filename = multipartFile.getOriginalFilename();
                String prefixName = filename.substring(0, filename.lastIndexOf("."));
                String suffixName = filename.substring(filename.lastIndexOf("."));
                filename = prefixName + Kit.getOrderID() + suffixName;

                byte[] bytes = multipartFile.getBytes();
                Path path = Paths.get(file_folder + filename);
                //如果没有files文件夹，则创建
                if (!Files.isWritable(path)) {
                    Files.createDirectories(Paths.get(file_folder));
                }
                //文件写入指定路径
                Files.write(path, bytes);
                String imgPath = request.getScheme() + "://" + serverAddress + ":" + request.getServerPort() + "/file/" + filename;
                paths.add(imgPath);
            } catch (IOException e) {
                e.printStackTrace();
                log.info("上传多文件失败" + e);
                return null;
            }
        }
        return paths;
    }
}
