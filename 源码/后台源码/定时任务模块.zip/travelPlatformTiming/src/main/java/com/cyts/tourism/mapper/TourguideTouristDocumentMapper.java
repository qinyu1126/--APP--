package com.cyts.tourism.mapper;

import com.cyts.tourism.base.entity.TourguideTouristDocument;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * im文档传送记录表 Mapper 接口
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
public interface TourguideTouristDocumentMapper extends BaseMapper<TourguideTouristDocument> {

}
