package com.cyts.tourism.utils;

import com.tencentyun.TLSSigAPIv2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author : ZhaoShy
 * @ClassName : TencentIMUtil
 * @Description : 腾讯 IM 工具类
 * @Date : 2021年05月20日 15:45
 * @Vlog : 见贤思齐, 从善如流
 */
@Configuration
public class TencentIMUtil {

    @Value("${IMConfig.sdkAppId}")
    private long sdkAppId;
    @Value("${IMConfig.secretKey}")
    private String secretKey;

    @Autowired
    RedisUtil redisUtil;

    /**
     * @Author : ZhaoShy
     * @Description : 获取 UserSig
     * @Date : 2021/5/20 15:58
     * @Vlog : 精益求精
     */
    public String generateUserSig(String userId) {
        String key = "im_user_id_" + userId;
        long expire1 = redisUtil.getExpire(key);
        if (expire1 >= 0) {
            return redisUtil.get(key);
        } else {
            List<String> list = new ArrayList<>();
            list.add(key);
            redisUtil.del(list);
        }
        TLSSigAPIv2 api = new TLSSigAPIv2(sdkAppId, secretKey);
        long expire = 604800L;
        String userSig = api.genSig(userId, expire);
        //将 USERSIG 存放到 Redis中, 过期时间为 7 天
        redisUtil.set(key, userSig, expire);
        return userSig;
    }

    /**
     * 封装请求头, 参数格式json
     * @param jsonStr
     * @return
     */
    public HttpEntity<String> getJsonReq(String jsonStr) {
        HttpHeaders headers = new HttpHeaders();
        MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
        headers.setContentType(type);
        headers.add("Accept", MediaType.APPLICATION_JSON.toString());
        return new HttpEntity<String>(jsonStr, headers);
    }
}
