package com.cyts.tourism.mapper;

import com.cyts.tourism.base.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 用户信息 Mapper 接口
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-08
 */
public interface UserMapper extends BaseMapper<User> {
    User selectByImUserId(String imUserId);
}
