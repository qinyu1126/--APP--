package com.cyts.tourism.utils;

public class PushResults {

    private String result;
    private String taskId;
    private String status;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "PushResults [result=" + result + ", taskId=" + taskId + ", status=" + status + "]";
    }

}
