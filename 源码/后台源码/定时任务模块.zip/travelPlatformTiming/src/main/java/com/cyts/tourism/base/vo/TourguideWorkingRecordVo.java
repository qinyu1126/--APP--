package com.cyts.tourism.base.vo;

import com.cyts.tourism.base.Pagination;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>
 * 导游工作表数据传输对象
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@ApiModel(value = "TourguideWorkingRecordVo", description = "导游工作表数据传输对象")
@Data
public class TourguideWorkingRecordVo extends Pagination {

    @ApiModelProperty(value = "", name = "id")
    private Integer id;
    /**
     * 发送方IMuserId
     */
    @ApiModelProperty(value = "发送方IMuserId", name = "sendUserId")
    private String tourguideUserId;

    /**
     * 接收方IMuserId
     */
    @ApiModelProperty(value = "接收方IMuserId", name = "receiveUserId")
    private String touristUserId;
    /**
     * 导游游客关联ID
     */
    @ApiModelProperty(value = "导游游客关联ID", name = "tourguideTouristId")
    private Integer tourguideTouristId;
    /**
     * 任何一条IM开始时间
     */
    @ApiModelProperty(value = "任何一条IM开始时间", name = "startTime")
    private Date startTime;

    @ApiModelProperty(value = "统计时间", name = "countTime")
    private String countTime;
    private Integer countPeople;
    /**
     * 消息统计
     */
    @ApiModelProperty(value = "消息统计", name = "countMsg")
    private int countMsg;
    /**
     * 消息类型(1.文字, 2.语音, 3.视频)
     */
    @ApiModelProperty(value = "消息类型(1.文字, 2.语音, 3.视频)", name = "type")
    private int type;
    /**
     * 文本统计
     */
    @ApiModelProperty(value = "文本统计", name = "txtAcount")
    private Integer txtAcount;
    /**
     * 语音时长
     */
    @ApiModelProperty(value = "语音时长", name = "voiceDuration")
    private Double voiceDuration;
    /**
     * 视频时长
     */
    @ApiModelProperty(value = "视频时长", name = "vedioDuration")
    private Double vedioDuration;

    //--------------------------------------------------------------------------------

}
