package com.cyts.tourism.base.bo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * <p>
 * im文档传送记录表数据传输对象
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@ApiModel(value = "TourguideTouristDocumentBo", description = "im文档传送记录表数据传输对象")
@Data
public class TourguideTouristDocumentBo {

    @ApiModelProperty(value = "", name = "id")
    private Integer id;
    /**
     * 发送方IMuserId
     */
    @ApiModelProperty(value = "发送方IMuserId", name = "sendUserId")
    private String tourguideUserId;

    /**
     * 接收方IMuserId
     */
    @ApiModelProperty(value = "接收方IMuserId", name = "receiveUserId")
    private String touristUserId;
    /**
     * 导游工作记录表
     */
    @ApiModelProperty(value = "导游工作记录表", name = "workingId")
    private Integer workingId;
    /**
     * 图片,文档,短视频等url地址
     */
    @ApiModelProperty(value = "图片,文档,短视频等url地址", name = "fileUrl")
    private String fileUrl;
    /**
     * 发送时间
     */
    @ApiModelProperty(value = "发送时间", name = "startTime")
    private Date startTime;

    //--------------------------------------------------------------------------------

}
