package com.cyts.tourism.base.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 用户信息
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-08
 */
@Data
@TableName("t_user")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private Integer id;

    /**
     * IM 使用 UserId
     */
    private String imUserId;

    /**
     * 登录账号
     */
    private String username;

    /**
     * 登录密码
     */
    private String password;

    /**
     * 姓
     */
    private String surName;

    /**
     * 名
     */
    private String givenName;

    /**
     * 拼音名
     */
    private String pinyin;

    /**
     * 身份证号 / 护照号
     */
    private String idNum;
    private String countryCode;

    /**
     * 性别(1,女, 2.男)
     */
    private Integer gender;

    /**
     * 手机号
     */
    private String mobileNum;

    /**
     * 邮箱
     */
    private String eMail;

    /**
     * 头像图片
     */
    private String imageCardUrl;

    /**
     * 导游证件照
     */
    private String imageLicense;

    /**
     * 开户银行
     */
    private String bankName;

    /**
     * 银行账户
     */
    private String bankAccount;

    /**
     * 是否兼职客服(0.不是, 1.是)
     */
    private Integer callCenterStatus;

    /**
     * 个人简介
     */
    private String selfDescription;

    /**
     * 审核状态(0.未通过 1.审核中 2.审核通过)
     */
    private Integer certifiedStatus;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private Date createDate;

    /**
     * 更新时间
     */
    @TableField(fill = FieldFill.UPDATE)
    private Date updateDate;

    /**
     * 用户类型(1.导游; 2.游客)
     */
    private Integer type;

    /**
     * 角色ID
     */
    private Integer roleId;


    /**
     * 展示ID
     */
    private Integer viewId;

    /**
     * 客户端标识
     */
    private String clientId;

}
