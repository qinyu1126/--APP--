package com.cyts.tourism.utils;


import net.sf.cglib.beans.BeanCopier;
import net.sf.cglib.beans.BeanMap;
import net.sf.cglib.core.Converter;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.util.*;

public class BeanUtils extends org.springframework.beans.BeanUtils {

    public static void copyProperties(Object source, Object target) {
    	if(null == source  ){
    		return ;
		}
        BeanCopier copier = BeanCopier.create(source.getClass(), target.getClass(), false);
        copier.copy(source, target, null);

    }

    public static void copyProperties(Object source, Object target, Converter converter) {
        BeanCopier copier = BeanCopier.create(source.getClass(), target.getClass(), true);
        copier.copy(source, target, converter);
    }
    

    /**
     * 批量拷贝集合的方法
     * @param sourceList
     * @param targetList
     * @param clasz
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
	public static <T, V> ArrayList<V> copyPropertieses(List<T> sourceList, ArrayList<V> targetList, Class<?> clasz) {
    	try {
			if (sourceList != null && sourceList.size() >= 1) {
				for (T t : sourceList) {
						V instance = (V)clasz.newInstance();
						copyProperties(t, instance);
						targetList.add(instance);
				}
				return targetList;
			}
			return targetList;
		} catch (Exception e) {
			return null;
		}
    }

	public static String[] getNullPropertyNames (Object source) {
		final BeanWrapper src = new BeanWrapperImpl(source);
		java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

		Set<String> emptyNames = new HashSet<String>();
		for(java.beans.PropertyDescriptor pd : pds) {
			Object srcValue = src.getPropertyValue(pd.getName());
			if (srcValue == null) emptyNames.add(pd.getName());
		}
		String[] result = new String[emptyNames.size()];
		return emptyNames.toArray(result);
	}

	/**
	 * 将对象装成map形式 注意：生成的是unmodifiableMap
	 *
	 * @param src 源对象
	 * @return {Map<K, V>}
	 */
	@SuppressWarnings("unchecked")
	public static <K, V> Map<K, V> toMap(Object src) {
		return BeanMap.create(src);
	}

	/**
	 * @Description <p> 拷贝非空对象属性值 </P>
	 * @param source 源对象
	 * @param target 目标对象
	 */
	public static void copyPropertiesIgnoreNull(Object source, Object target) {
		org.springframework.beans.BeanUtils.copyProperties(source, target, getNullPropertyNames(source));
	}
}
