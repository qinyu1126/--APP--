package com.cyts.tourism.mapper;

import com.cyts.tourism.base.entity.Country;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 国家字典 Mapper 接口
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
public interface CountryMapper extends BaseMapper<Country> {

    String getCountryNameByCode(String countryCode);
}
