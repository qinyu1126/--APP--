package com.cyts.tourism.base;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.Data;

/**
 * @author DY2020
 * @date 2020-4-20
 **/
@Data
public class Pagination {

    /**
     * 升序
     */
    public final static String ASC = "asc";
    /**
     * 降序
     */
    public final static String DESC = "desc";

    /**每页数据条数*/
    private Integer pageSize;
    /**分页页码*/
    private Integer pageNum;
    /**排序字段*/
    private String orderBy;
    /**排序顺序*/
    private String orderDirection;
    /**查询参数*/
    private String queryInfo;
    private String searchStatus;

    public <T> Page<T> getPage() {
        int pageSize = this.pageSize != null ? this.pageSize : 10;
        int pageNum = this.pageNum != null ? this.pageNum : 1;
        return new Page<>(pageNum, pageSize);
    }
}
