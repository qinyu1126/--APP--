package com.cyts.tourism.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cyts.tourism.base.bo.TourguideTouristDocumentBo;
import com.cyts.tourism.base.entity.TourguideTouristDocument;

/**
 * <p>
 * im文档传送记录表 服务类
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
public interface ITourguideTouristDocumentService extends IService<TourguideTouristDocument> {

    public void insert(TourguideTouristDocumentBo tourguideTouristDocumentBo);

}
