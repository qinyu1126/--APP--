package com.cyts.tourism.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cyts.tourism.base.BaseRespBo;
import com.cyts.tourism.base.bo.TourguideWorkingRecordBo;
import com.cyts.tourism.base.entity.TourguideWorkingRecord;
import com.cyts.tourism.base.vo.TourguideWorkingRecordVo;

import java.util.List;

/**
 * <p>
 * 导游工作表 服务类
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
public interface ITourguideWorkingRecordService extends IService<TourguideWorkingRecord> {

    public void insert(TourguideWorkingRecordBo tourguideWorkingRecordBo);

}
