package com.cyts.tourism.utils;


import com.gexin.rp.sdk.base.IPushResult;
import com.gexin.rp.sdk.base.impl.ListMessage;
import com.gexin.rp.sdk.base.impl.SingleMessage;
import com.gexin.rp.sdk.base.impl.Target;
import com.gexin.rp.sdk.base.notify.Notify;
import com.gexin.rp.sdk.base.payload.APNPayload;
import com.gexin.rp.sdk.dto.GtReq;
import com.gexin.rp.sdk.exceptions.RequestException;
import com.gexin.rp.sdk.http.IGtPush;
import com.gexin.rp.sdk.template.TransmissionTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class GeTuiPushApi {


//    AppId: 2JQRLkIMqWA3N4UnrvePG6
//    AppKey: j7JzE8ILyD9V0Sw9UnLVC9
//    MasterSecret: C5S5Q0M7yjAv0Olql5Qgt4
//    Domain: https://restapi.getui.com/v2/

//    private  static String  APPID="Xl5mlQ8SJs6BTNOZVUuKt5";
//    private  static String  APPKEY="qejkDCPjdg6DagqJlgN4n3";
//    private  static String  MASTERSECRET="W6GYsVXMtq662FdLBf5m27";

    private  static String  APPID="2JQRLkIMqWA3N4UnrvePG6";
    private  static String  APPKEY="j7JzE8ILyD9V0Sw9UnLVC9";
    private  static String  MASTERSECRET="C5S5Q0M7yjAv0Olql5Qgt4";

    //    @Resource
//    public PushApi pushApi;

//    @Resource
//    public Settings settings;

    private static String host = "http://sdk.open.api.igexin.com/apiex.htm";





    //创建ios消息

//   public IosDTO createIosDTO(IosInfoBo iosInfoBo){
//        //ios消息
//        IosDTO iosDTO = new IosDTO();
//        //notify默认通知消息	voip：voip语音推送，notify：apns通知消息
//        iosDTO.setType("notify");
//        //自定义消息
////        iosDTO.setPayload(iosInfoBo.getPayload());
//        //推送通知消息内容
//        Aps aps = new Aps();
//        // 0表示普通通知消息(默认为0)；
//        // 1表示静默推送(无通知栏消息)，静默推送时不需要填写其他参数。
//        // 苹果建议1小时最多推送3条静默消息
//        aps.setContentAvailable(0);
////        通知铃声文件名，如果铃声文件未找到，响铃为系统默认铃声。
////        无声设置为“com.gexin.ios.silence”或不填
//        aps.setSound("com.gexin.ios.silence");
////        在客户端通知栏触发特定的action和button显示
//        aps.setCategory("ACTIONABLE");
////      用于计算icon上显示的数字，还可以实现显示数字的自动增减，如“+1”、 “-1”、 “1” 等，计算结果将覆盖badge
//        iosDTO.setAutoBadge("+1");
//        //多媒体设置
////        iosDTO.setMultimedia(iosInfoBo.getMultimediaList());
////        aps.setAlert(iosInfoBo.getAlert());
//        iosDTO.setAps(aps);
//        return iosDTO;
//    };





    //toList执行cid批量推
//    public  Map<String, Map<String, String>>  toListCid(GTNotification notification, Audience audience) {
//        //此接口用来创建消息体，并返回taskid，为批量推的前置步骤
//        //创建任务消息
//        String taskId=null;
//        PushDTO pushDTO = new PushDTO();
//        pushDTO.setSettings(settings);
//        log.info("推送消息参数"+settings.toString());
//        //创建消息对象
//        PushMessage pushMessage = new PushMessage();
//        //放入消息内容
//        pushMessage.setNotification(notification);
//
//        pushMessage.setNetworkType(0);
//
//
//        pushDTO.setPushMessage(pushMessage);
//        ApiResult<TaskIdDTO> msg = pushApi.createMsg(pushDTO);
//        if (msg.isSuccess()) {
//            //获取创建的消息任务
//            taskId = msg.getData().getTaskId();
//
//            //根据taskId推送消息
//            AudienceDTO audienceDTO = new AudienceDTO();
//            audienceDTO.setAsync(true);
//            audienceDTO.setTaskid(taskId);
//            audienceDTO.setAudience(audience);
//            ApiResult<Map<String, Map<String, String>>> apiResult = pushApi.pushListByCid(audienceDTO);
//            if (apiResult.isSuccess()) {
//                // success
//                return apiResult.getData();
//            } else {
//                log.error("code:" + apiResult.getCode() + ",  msg:推送消息出错-------> " + apiResult.getMsg());
//            }
//        } else {
//            log.error("code:" + msg.getCode() + ", msg: 创建消息出错------>" + msg.getMsg());
//        }
//        return null;
//    }

    public static Map<String, Object> pushList(List<String> cList, String text, String beanToString) {
        Map<String, Object> dmap = new HashMap<String, Object>();
            Map map = new HashMap();
            map.put("title",text);
            map.put("content", beanToString);
            String json = GsonKit.mapToJson(map);
            System.out.println(json);
            List<String> iosList = new ArrayList<String>();
            List<String> androidList = new ArrayList<String>();
            try {
                for (int i = 0; i < cList.size(); i++) {
                    String cid = cList.get(i);
                    if (null != cid) {
                        if (cid.length() > 60) {
                            iosList.add(cid);
                        } else {
                            androidList.add(cid);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                if (iosList.size() > 0) {

                    IPushResult pushToIos = pushToIos(iosList, text, beanToString);
                    String contentId = null;
                    String result = null;
                    Map<String, String> details = null;
                    try {
                        Map<String, Object> response = pushToIos.getResponse();
                        String obj2String = ObjectMapperUtil.obj2String(response);
                        IOSPushResults string2Obj = ObjectMapperUtil.string2Obj(obj2String, IOSPushResults.class);
                        contentId = string2Obj.getContentId();
                        result = string2Obj.getResult();
                        details = string2Obj.getDetails();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                    if (details != null) {
                        try {
                            for (Map.Entry<String, String> m : details.entrySet()) {
                                PushResults pushResults = new PushResults();
                                pushResults.setTaskId(contentId);
                                pushResults.setStatus(m.getValue());
                                pushResults.setResult(result);
                                String obj2String2 = ObjectMapperUtil.obj2String(pushResults);
                                dmap.put(m.getKey(), obj2String2);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                 if(androidList.size()>0) {
                     Map<String, Object> android = android(androidList, text,beanToString );
                     dmap.putAll(android);
                 }
                System.err.println("======================已推送====================");
            } catch (Exception e) {
                e.printStackTrace();
                System.err.println("======================推送失败====================");
                return null;
            }

        return dmap;
    }

    /**
     * android 透传消息
     * @param cList
     * @param text
     * @param content
     * @return
     */
    public static Map<String, Object> android(List<String> cList, String text, String content) {
        IPushResult ret = null;
        IGtPush push = new IGtPush(host, APPKEY, MASTERSECRET);
        TransmissionTemplate template = transmissionTemplate(text, content);
        Map<String, Object> tmap = new HashMap<String, Object>();
        for (String cid : cList) {
            SingleMessage message = new SingleMessage();
            message.setOffline(true);
            // 离线有效时间，单位为毫秒，可选
            message.setOfflineExpireTime(24 * 3600 * 1000);
            message.setPushNetWorkType(0);
            message.setData(template);
            message.setStrategyJson("{\"default\":4,\"ios\":2,\"st\":4,\"hw\":4,\"xm\":4,\"vv\":4,\"mz\":4,\"op\":4}");
            // 可选，1为wifi，0为不限制网络环境。根据手机处于的网络情况，决定是否下发
            message.setPushNetWorkType(0);
            Target target = new Target();
            target.setAppId(APPID);
            target.setClientId(cid);
            // target.setAlias(Alias);
            try {
                ret = push.pushMessageToSingle(message, target);
            } catch (RequestException e) {
                e.printStackTrace();
                ret = push.pushMessageToSingle(message, target, e.getRequestId());
            }
            if (ret != null) {
                tmap.put(cid, ret.getResponse().toString());
                System.out.println(ret.getResponse().toString());
            } else {
                tmap.put(cid, "异常");
                System.out.println("服务器响应异常");
            }
        }
        return tmap;
    }

    /**
     * ios透传消息
     * @param dtl
     * @param text
     * @param content
     * @return
     */
    public static IPushResult pushToIos(List<String> dtl, String text, String content) {
        IPushResult ret = null;
        try {
            IGtPush push = new IGtPush(host, APPKEY, MASTERSECRET);
            TransmissionTemplate t = transmissionTemplate(text, content);
            APNPayload apnpayload = new APNPayload();
            apnpayload.setSound("");
            apnpayload.setContentAvailable(1);
            apnpayload.setCategory("由客户端定义");
            apnpayload.setAlertMsg(new APNPayload.SimpleAlertMsg("hello"));
            APNPayload.DictionaryAlertMsg dictionaryAlertMsg = new APNPayload.DictionaryAlertMsg();
            dictionaryAlertMsg.setTitle(text);
            dictionaryAlertMsg.setBody(content);
            apnpayload.setAlertMsg(dictionaryAlertMsg);
            apnpayload.addCustomMsg("parkinfo", content);
            t.setAPNInfo(apnpayload);
            ListMessage message = new ListMessage();
            message.setData(t);
            String taskId = push.getAPNContentId(APPID, message);
            System.out.println(taskId);
            System.setProperty("gexin.rp.sdk.pushlist.needDetails", "true");
            ret = push.pushAPNMessageToList(APPID, taskId, dtl);
            System.out.println(ret.getResponse());
            return ret;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 离线推送
     *
     * @param text
     * @param content
     * @return
     */
    public static TransmissionTemplate transmissionTemplate(String text, String content) {
        TransmissionTemplate template = new TransmissionTemplate();
        template.setAppId(APPID);
        template.setAppkey(APPKEY);
        template.setTransmissionContent(content);
        template.setTransmissionType(2);
        Notify notify = new Notify();
        notify.setTitle(text);
        notify.setContent(content);

        Map map = new HashMap();
        map.put("title",text);
        map.put("content", content);
        String json = GsonKit.mapToJson(map);
        notify.setIntent("intent:#Intent;launchFlags=0x04000000;action=android.intent.action.oppopush;package=com.zhidake.travel;component=com.zhidake.travel/io.dcloud.PandoraEntry;S.UP-OL-SU=true;S.title="+text+";S.content="+content+";S.payload="+json+";end");
        notify.setType(GtReq.NotifyInfo.Type._intent);
        try {
            template.set3rdNotifyInfo(notify);// 设置第三方通知
        } catch (Exception e) {
            e.printStackTrace();
        }
        return template;
    }
}