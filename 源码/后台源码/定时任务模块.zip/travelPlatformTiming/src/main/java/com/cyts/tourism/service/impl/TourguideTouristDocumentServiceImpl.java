package com.cyts.tourism.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cyts.tourism.base.bo.TourguideTouristDocumentBo;
import com.cyts.tourism.base.entity.TourguideTouristDocument;
import com.cyts.tourism.mapper.TourguideTouristDocumentMapper;
import com.cyts.tourism.service.ITourguideTouristDocumentService;
import com.cyts.tourism.utils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * im文档传送记录表 服务实现类
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@Service
public class TourguideTouristDocumentServiceImpl extends ServiceImpl<TourguideTouristDocumentMapper,TourguideTouristDocument> implements ITourguideTouristDocumentService {

    @Autowired
    TourguideTouristDocumentMapper tourguideTouristDocumentMapper;

    @Override
    public void insert(TourguideTouristDocumentBo tourguideTouristDocumentBo) {
        TourguideTouristDocument tourguideTouristDocument = new TourguideTouristDocument();
        BeanUtils.copyProperties(tourguideTouristDocumentBo, tourguideTouristDocument);
        tourguideTouristDocumentMapper.insert(tourguideTouristDocument);
    }
}
