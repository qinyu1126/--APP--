package com.cyts.tourism.timing;

import com.cyts.tourism.base.bo.TourguideTouristDocumentBo;
import com.cyts.tourism.base.bo.TourguideWorkingRecordBo;
import com.cyts.tourism.base.entity.IncomeStandard;
import com.cyts.tourism.base.entity.TourguideIncom;
import com.cyts.tourism.base.entity.User;
import com.cyts.tourism.mapper.*;
import com.cyts.tourism.service.ITourguideTouristDocumentService;
import com.cyts.tourism.service.ITourguideWorkingRecordService;
import com.cyts.tourism.utils.RedisUtil;
import com.cyts.tourism.utils.TimeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @Author : ZhaoShy
 * @ClassName : TimingCountMsg
 * @Description : 定时统计IM消息
 * @Date : 2021年06月03日 9:34
 * @Vlog : 见贤思齐, 从善如流
 */

@Slf4j
@Component
public class TimingTask {
    @Autowired
    RedisUtil redisUtil;
    @Autowired
    TimeUtil timeUtil;
    @Autowired
    ITourguideWorkingRecordService tourguideWorkingRecordService;
    @Autowired
    ITourguideTouristDocumentService tourguideTouristDocumentService;
    @Autowired
    IncomeStandardMapper incomeStandardMapper;
    @Autowired
    TourguideWorkingRecordMapper tourguideWorkingRecordMapper;
    @Autowired
    TourguideIncomMapper tourguideIncomMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    OrdersMapper ordersMapper;

    /**
     * 更新订单使用状态
     */
    @Scheduled(cron = "0 10 0 * * *")
//    @Scheduled(cron = "0 */5 * * * *")
    public void updateOrderStatus() {
        log.info("更新订单状态开始: =======================" + System.currentTimeMillis());
        SimpleDateFormat format =new SimpleDateFormat("yyyy-MM-dd");
        Date m = new Date();
        String today = format.format(m);
        ordersMapper.updateOrderStatus(today);
        log.info("更新订单状态结束: =======================" + System.currentTimeMillis());
    }

    /**
     * 每月1号0点统计客服费用结算
     */
    @Scheduled(cron = "0 0 0 1 * *")
//    @Scheduled(cron = "0 0 17 * * *")
    public void settle(){
        log.info("每月结算开始: =======================" + System.currentTimeMillis());
        //获取上个月
        SimpleDateFormat format =new SimpleDateFormat("yyyy-MM");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.MONTH, -1);
        Date m = c.getTime();
        String mon = format.format(m);
//        String mon = "2021-08";
        log.info("过去一个月：" + mon);
        //1. 查询结算标准
        IncomeStandard incomeStandard = incomeStandardMapper.selectById(1);
        //2. 统计上个月哪些导游做过服务
        List<String> ids = tourguideWorkingRecordMapper.countWorkingTourguideByLastMonth(mon);
        //3. 统计上个月导游服务天数
        for (String id: ids) {
            int days = tourguideWorkingRecordMapper.countWorkingDayByLastMonth(id, mon);
            double v = incomeStandard.getIncomeNum() * days;
            TourguideIncom tourguideIncom = new TourguideIncom();
            User user = userMapper.selectByImUserId(id);
            tourguideIncom.setTourguideId(user.getId());
            tourguideIncom.setTourguideName(user.getGivenName() + user.getSurName());
            log.info("导游计费: " + tourguideIncom.getTourguideName() + "==============" + v);
            tourguideIncom.setSettleMonth(mon);
            tourguideIncom.setInCome(v);
            tourguideIncomMapper.insert(tourguideIncom);
        }
        log.info("每月结算结束: =======================" + System.currentTimeMillis());
    }

    /**
     * 每天凌晨1点执行IM消息统计
     */
    @Scheduled(cron = "0 0 1 * * *")
//    @Scheduled(cron = "0 */10 * * * *")
    public void timingCountMsg(){
        log.info("消息统计开始: ============" + System.currentTimeMillis());
        //获取昨天日期
        String yesterday = timeUtil.getYesterday(new Date());
//        String yesterday = timeUtil.getFormatDateByTime(System.currentTimeMillis());
        //文字消息
        String keyText = "text_" + yesterday + "|";
        List<String> keysText = redisUtil.findKeys(keyText);
        if (null != keysText && keysText.size() > 0) {
            log.info("文本记录统计: " + keysText.toString());
            for (String textKey: keysText) {
                String num = redisUtil.get(textKey);
                String[] split = textKey.split("\\|");
                String sendUserIdText = split[1];
                String receiveUserIdText = split[2];
                long time = Long.parseLong(split[3]);
                TourguideWorkingRecordBo tourguideWorkingRecord = new TourguideWorkingRecordBo();
                tourguideWorkingRecord.setTourguideUserId(sendUserIdText);
                tourguideWorkingRecord.setTouristUserId(receiveUserIdText);
                tourguideWorkingRecord.setStartTime(timeUtil.getDateByTime(time));
                tourguideWorkingRecord.setCountMsg(Integer.parseInt(num));
                tourguideWorkingRecord.setType(1);
                tourguideWorkingRecordService.insert(tourguideWorkingRecord);
            }
            redisUtil.del(keysText);
        }
        //语音消息
        String keyVoice = "voice_" + yesterday + "|";
        List<String> keysVoice = redisUtil.findKeys(keyVoice);
        if (null != keysVoice && keysVoice.size() > 0) {
            log.info("语音记录统计: " + keysVoice.toString());
            for (String voiceKey: keysVoice) {
                String num = redisUtil.get(voiceKey);
                String[] split = voiceKey.split("\\|");
                String sendUserIdText = split[1];
                String receiveUserIdText = split[2];
                long time = Long.parseLong(split[3]);
                TourguideWorkingRecordBo tourguideWorkingRecord = new TourguideWorkingRecordBo();
                tourguideWorkingRecord.setTourguideUserId(sendUserIdText);
                tourguideWorkingRecord.setTouristUserId(receiveUserIdText);
                tourguideWorkingRecord.setStartTime(timeUtil.getDateByTime(time));
                tourguideWorkingRecord.setCountMsg(Integer.parseInt(num));
                tourguideWorkingRecord.setType(2);
                tourguideWorkingRecordService.insert(tourguideWorkingRecord);
            }
            redisUtil.del(keysVoice);
        }
        //视频消息
        String keyVideo = "video_" + yesterday + "|";
        List<String> keysVideo = redisUtil.findKeys(keyVideo);
        if (null != keysVideo && keysVideo.size() > 0) {
            log.info("视频记录统计: " + keysVideo.toString());
            for (String videoKey: keysVideo) {
                String num = redisUtil.get(videoKey);
                String[] split = videoKey.split("\\|");
                String sendUserIdText = split[1];
                String receiveUserIdText = split[2];
                long time = Long.parseLong(split[3]);
                TourguideWorkingRecordBo tourguideWorkingRecord = new TourguideWorkingRecordBo();
                tourguideWorkingRecord.setTourguideUserId(sendUserIdText);
                tourguideWorkingRecord.setTouristUserId(receiveUserIdText);
                tourguideWorkingRecord.setStartTime(timeUtil.getDateByTime(time));
                tourguideWorkingRecord.setCountMsg(Integer.parseInt(num));
                tourguideWorkingRecord.setType(3);
                tourguideWorkingRecordService.insert(tourguideWorkingRecord);
            }
            redisUtil.del(keysVideo);
        }
        //图片文件消息
        String keyImage = "image_" + yesterday + "|";
        List<String> keysImage = redisUtil.findKeys(keyImage);
        if (null != keysImage && keysImage.size() > 0) {
            for (String imageKey: keysImage) {
                String num = redisUtil.get(imageKey);
                String[] split = imageKey.split("\\|");
                String sendUserIdText = split[1];
                String receiveUserIdText = split[2];
                long time = Long.parseLong(split[3]);
                String url = split[4];
                TourguideTouristDocumentBo tourguideTouristDocumentBo = new TourguideTouristDocumentBo();
                tourguideTouristDocumentBo.setTourguideUserId(sendUserIdText);
                tourguideTouristDocumentBo.setTouristUserId(receiveUserIdText);
                tourguideTouristDocumentBo.setStartTime(timeUtil.getDateByTime(time));
                tourguideTouristDocumentBo.setFileUrl(url);
                tourguideTouristDocumentService.insert(tourguideTouristDocumentBo);
            }
            redisUtil.del(keysImage);
        }
        log.info("消息统计结束: ============" + System.currentTimeMillis());
    }
}
