package com.cyts.tourism.base.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 导游收入表
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@Data
@TableName("t_tourguide_incom")
public class TourguideIncom implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private Integer id;

    /**
     * 导游ID
     */
    private Integer tourguideId;
    private String tourguideName;
    private String settleMonth;

    /**
     * 收入
     */
    private Double inCome;

    /**
     * 支付状态 0=未支付 1=已支付
     */
    private Integer paymentStatus;

    /**
     * 支付日期时间
     */
    private Date payTime;
    private Integer operatorId;
    private String operatorName;

    private double realSettle;
    private String bankWorkNo;
    private String transferPath;


}
