package com.cyts.tourism.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @Author: ZhaoSHy
 * @Vlog: 精益求精
 * @Description: Mybatis-Plus 自动填充
 * @Date: 2021/5/4 9:12
 */
@Slf4j
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {
        log.info("开启 insert 填充");
        this.strictInsertFill(metaObject, "createDate", Date.class, new Date());
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        log.info("开启 update 填充");
        log.info(new Date().toString());
        this.strictUpdateFill(metaObject, "updateDate", Date.class, new Date());
    }
}
