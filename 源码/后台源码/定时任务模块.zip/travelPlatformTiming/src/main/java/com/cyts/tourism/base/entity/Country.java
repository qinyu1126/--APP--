package com.cyts.tourism.base.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * <p>
 * 国家字典
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@Data
@TableName("t_country")
public class Country implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private Integer id;

    /**
     * 国家名称中文
     */
    private String countryNameCn;

    /**
     * 国家英文简称
     */
    private String countryNameAb;

    /**
     * 国家名称英文
     */
    private String countryNameEn;

    /**
     * 国家区号
     */
    private String countryCode;

    /**
     * 所属洲编号'1=亚洲 2=欧洲 3=北美洲 4=南美洲 5=大洋洲 6=非洲 7=中美洲
     */
    private Integer continentCode;

    /**
     * 默认排序
     */
    private Integer defaultSort;



}
