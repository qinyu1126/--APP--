package com.cyts.tourism.base.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * im文档传送记录表
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@Data
@TableName("t_tourguide_tourist_document")
public class TourguideTouristDocument implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private Integer id;
    /**
     * 发送方IMuserId
     */
    private String tourguideUserId;

    /**
     * 接收方IMuserId
     */
    private String touristUserId;

    /**
     * 导游工作记录表
     */
    private Integer workingId;

    /**
     * 图片,文档,短视频等url地址
     */
    private String fileUrl;

    /**
     * 发送时间
     */
    private Date startTime;
}
