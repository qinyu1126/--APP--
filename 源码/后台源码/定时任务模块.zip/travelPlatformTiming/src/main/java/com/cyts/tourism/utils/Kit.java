package com.cyts.tourism.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class Kit {
    /**
     * 获取uuid
     */
    public static String getUUID() {

        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    /**
     * 创建时间格式订单ID
     * @return
     */
    public static String getOrderID() {
        int rannum = (int) ((Math.random() * 9 + 1) * 100000);// 获取6位随机数
        return getDatestr() + rannum;
    }

    public static String getDatestr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date2 = new Date();
        return sdf.format(date2);
    }
}