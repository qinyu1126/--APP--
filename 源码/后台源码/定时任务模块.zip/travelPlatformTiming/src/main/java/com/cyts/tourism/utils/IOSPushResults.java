package com.cyts.tourism.utils;

import java.util.Map;

public class IOSPushResults {

    private String result;
    private String contentId;
    private Map<String, String> details;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public Map getDetails() {
        return details;
    }

    public void setDetails(Map details) {
        this.details = details;
    }

}
