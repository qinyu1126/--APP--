package com.cyts.tourism.base.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 导游工作表
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@Data
@TableName("t_tourguide_working_record")
public class TourguideWorkingRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private Integer id;
    /**
     * 发送方IMuserId
     */
    private String tourguideUserId;

    /**
     * 接收方IMuserId
     */
    private String touristUserId;

    /**
     * 导游游客关联ID
     */
    private Integer tourguideTouristId;

    /**
     * 任何一条IM开始时间
     */
    private Date startTime;

    private String countTime;

    private Integer countPeople;
    /**
     * 消息统计
     */
    private int countMsg;
    /**
     * 消息类型(1.文字, 2.语音, 3.视频)
     */
    private int type;
    /**
     * 文本统计
     */
    private Integer txtAcount;

    /**
     * 语音时长
     */
    private Double voiceDuration;

    /**
     * 视频时长
     */
    private Double vedioDuration;

    private double money;



}
