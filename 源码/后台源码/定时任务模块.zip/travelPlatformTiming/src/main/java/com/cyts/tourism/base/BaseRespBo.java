package com.cyts.tourism.base;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 基础响应类
 */
@Data
public class BaseRespBo<T> implements Serializable {

    @ApiModelProperty(value = "数据总记录数")
    private Integer totalCount;

    @ApiModelProperty(value = "数据总记录数")
    private double money;

    @ApiModelProperty(value = "单条数据")
    private T entityData;

    @ApiModelProperty(value = "分页(单页)数据集合")
    private List<T> pageData;

    @ApiModelProperty(value = "分页(单页)数据集合")
    private Page<T> tPage;

    @ApiModelProperty(value = "请求响应成功/失败状态")
    private Boolean status;

    @ApiModelProperty(value = "请求响应返回信息提示")
    private String message;

    @ApiModelProperty(value = "请求响应返回编码")
    private String code;

    @ApiModelProperty(value = "附加数据结果对象")
    private Map<String,T> objData;

    @ApiModelProperty(value = "附加数据结果对象集合")
    private List<T> objPageData;
}
