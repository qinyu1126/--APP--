package com.cyts.tourism.base.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 订单详情
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@Data
@TableName("t_orders")
public class Orders implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private Integer id;

    /**
     * 游客ID
     */
    private Integer touristId;

    /**
     * 商品ID
     */
    private Integer commodityId;

    /**
     * 商品数量
     */
    private Integer goodsAmount;

    /**
     * 商品单价
     */
    private Double unitPrice;

    /**
     * 订单总价
     */
    private Double totalPrice;

    /**
     * 取货地址ID
     */
    private Integer addressId;

    /**
     * 支付日期时间
     */
    private Date payTime;

    /**
     * 取货日期时间
     */
    private Date pickTime;

    /**
     * 归还日期时间
     */
    private Date returnTime;

    @TableField(fill = FieldFill.INSERT)
    private Date createDate;

    /**
     * 订单状态 1=待适用 2=使用中 3=退款中 4 =已退款  5= 使用中  6=已归还
     */
    private Integer orderStatus;

    private String specialRequest;

    private Double orderDeposit;

    private String contact;

    private String phone;

    private String passport;

    private String orderNo;

    /**
     * paypal成功支付口令
     */
    private String payToken;

    private Integer priceId;

    private Integer depositStatus;

    private Date refundDate;

    @ApiModelProperty(value = "支付方式", name = "paymentMethod")
    private Integer paymentMethod;

}
