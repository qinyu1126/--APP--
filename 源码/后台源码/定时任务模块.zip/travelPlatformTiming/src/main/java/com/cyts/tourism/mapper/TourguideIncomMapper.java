package com.cyts.tourism.mapper;

import com.cyts.tourism.base.entity.TourguideIncom;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 导游收入表 Mapper 接口
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
public interface TourguideIncomMapper extends BaseMapper<TourguideIncom> {

    double countTotal(Integer id);

    TourguideIncom selectPaymentStatus(@Param("queryUserId") String queryUserId, @Param("queryDate") String queryDate);
}
