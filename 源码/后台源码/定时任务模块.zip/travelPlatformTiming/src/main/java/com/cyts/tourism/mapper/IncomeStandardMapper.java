package com.cyts.tourism.mapper;

import com.cyts.tourism.base.entity.IncomeStandard;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 导游计费标准表 Mapper 接口
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
public interface IncomeStandardMapper extends BaseMapper<IncomeStandard> {

}
