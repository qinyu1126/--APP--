package com.cyts.tourism.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by liwenlong on 2019-02-22
 * description: 字符串工具类
 */
public class EnnStringUtil extends StringUtils {


	public static final Pattern P_IS_DOUBLE = Pattern.compile("\\d+\\.\\d+");
	public static final Pattern P_IS_NUMBER = Pattern.compile("[0-9]+");

	/**
	 * 是否为小数
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isDouble(String str) {

		return P_IS_DOUBLE.matcher(str).matches();
	}
	
	public static boolean isNumber(String str) {
		Matcher match = P_IS_NUMBER.matcher(str);
		return match.matches();
	}


	/**
	 * 判断long类型是否为空
	 * @param str
	 * @return
	 */
	public static boolean isLongBlank(Long str) {
		if( null == str ){
			return true;
		}
		return StringUtils.isBlank(str.toString());
	}

	/**
	 * 判断long类型是否为空
	 * @param str
	 * @return
	 */
	public static boolean isLongNotBlank(Long str) {
		return !EnnStringUtil.isLongBlank(str);
	}

	/**
	 * 判断integer类型是否为空
	 * @param str
	 * @return
	 */
	public static boolean isIntegerBlank(Integer str) {
		if( null == str ){
			return true;
		}
		return StringUtils.isBlank(str.toString());
	}

	/**
	 * 判断long类型是否为空
	 * @param str
	 * @return
	 */
	public static boolean isIntegerNotBlank(Integer str) {
		return !EnnStringUtil.isIntegerBlank(str);
	}

}
