package com.cyts.tourism.mapper;

import com.cyts.tourism.base.entity.TourguideWorkingRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cyts.tourism.base.vo.TourguideWorkingRecordVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 导游工作表 Mapper 接口
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
public interface TourguideWorkingRecordMapper extends BaseMapper<TourguideWorkingRecord> {
    int countWorkingDayByLastMonth(@Param("id") String id, @Param("mon") String mon);
    List<String> countWorkingTourguideByLastMonth(String mon);
}
