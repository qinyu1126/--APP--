package com.cyts.tourism.base.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 导游计费标准表
 * </p>
 *
 * @author ZhaoShy
 * @since 2021-05-06
 */
@Data
@TableName("t_income_standard")
public class IncomeStandard implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private Integer id;
    @TableField(fill = FieldFill.UPDATE)
    private Date updateDate;
    /**
     * 劳务费名目
     */
    private String incomeName;
    /**
     * 收入金额标准
     */
    private Double incomeNum;
    /**
     * 计费标准 1=按小时 2=按自然日 3=按周 4=按月
     */
    private Integer chargeTime;
    /**
     * 发布统计数据时间
     */
    private String balanceHour;

}
